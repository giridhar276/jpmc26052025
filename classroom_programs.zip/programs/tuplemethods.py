

atup = (10,20,30,10,10,10,10,30,30)

print(atup.count(10))

print(atup.index(30))