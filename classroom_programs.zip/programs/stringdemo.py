name = "python programming"
print(name)
print("I love", name)
print(1,2,3,4)
#slicing
#string[start:stop:step]
print(name[0])
print(name[1])
print(name[0:8])
print(name[8:14])
print(name[:])   # start = 0    stop=18   
print(name[::])  # start = 0    stop=18   step =1
print(name[0:18]) #default step is 1
print(name[0:18:1])
print(name[0:18:2])
print(name[-1])
print(name[-2])
print(name[-5:-1])
print(name[::-1])
#p    y     t     h    o     n         p    r    o    g   r   a  m   m   i    n   g
#0    1     2     3    4     5    6    7    8    9   10  11  12  13  14  15  16  17
# 
#                                                                -5  -4  -3  -2  -1
  