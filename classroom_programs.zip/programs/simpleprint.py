

# library version
import matplotlib
print(matplotlib.__version__)


# python version
import sys
print(sys.version)