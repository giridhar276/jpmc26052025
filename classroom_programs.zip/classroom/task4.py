#write a program to count no. of words in a sentence.


text = input("Enter a sentence:")

getcount = len(text.split(" "))
print("No. of words in sentence :", getcount)