
name = "python"
name[0] = "J"
print(name)
